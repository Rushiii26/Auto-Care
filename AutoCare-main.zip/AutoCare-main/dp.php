<?php

 $dbhost="localhost";
 $dbuser="root";

